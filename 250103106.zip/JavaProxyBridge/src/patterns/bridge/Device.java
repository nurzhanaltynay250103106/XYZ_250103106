package patterns.bridge;

public interface Device {
    void turnOn();
    void turnOff();
    void setVolume(int level);
}
