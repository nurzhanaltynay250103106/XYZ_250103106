@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
dir /s /b src\*.java > build\sources.txt
javac --release 8 -encoding UTF-8 -d build\classes @build\sources.txt
if errorlevel 1 exit /b 1
set "MAIN=patterns.Main"
if not "%~1"=="" set "MAIN=%~1"
java -cp build\classes %MAIN%
