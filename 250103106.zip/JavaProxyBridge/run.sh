#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes
find src -name '*.java' | sort > build/sources.txt
javac --release 8 -encoding UTF-8 -d build/classes @build/sources.txt
java -cp build/classes "${1:-patterns.Main}"
