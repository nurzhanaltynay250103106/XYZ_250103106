package patterns.demo;

import patterns.proxy.*;
import patterns.bridge.*;
import patterns.bridge.rpg.*;

public class Task5Demo {
    public static void main(String[] args) {
        PartyRemote remote = new PartyRemote(new Radio());
        remote.partyMode();
    }
}
