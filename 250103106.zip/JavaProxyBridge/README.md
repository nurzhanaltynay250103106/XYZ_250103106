# Java: Proxy & Bridge — все 6 заданий

Готовое решение JavaDesignPatternsTaskSheetProxyandBridge.pdf. Без внешних библиотек и без сетевых обращений: загрузка изображений и видео имитируется сообщениями, как в PDF.

## Требования и запуск

Нужен JDK 9 или новее (`java` и `javac` в PATH). Исходники компилируются с `--release 8` и совместимы с Java 8. Проверено на OpenJDK 24.0.2.

macOS / Linux:
```sh
sh run.sh
sh run.sh patterns.demo.Task1Demo
```
Windows:
```bat
run.bat
run.bat patterns.demo.Task1Demo
```
Любую задачу можно запустить отдельно, заменив номер в `Task1Demo` на 1–6. В IDE откройте папку, отметьте `src` как Sources Root и запустите `patterns.Main` либо нужный `TaskNDemo`.

## Соответствие заданиям

| № | Задание | Классы |
|---|---|---|
| 1 | The Bouncer | Image, RealImage, ProxyImage |
| 2 | The View Counter | Video, RealVideo, ProxyVideo |
| 3 | School Wi-Fi Firewall | Internet, RealInternet, SchoolProxyInternet |
| 4 | The New Machine | Device, SmartLight, BasicRemote, AdvancedRemote |
| 5 | The New Button | Radio, PartyRemote (extends BasicRemote) |
| 6 | RPG Game Weapon System | Weapon, Sword, MagicWand, Hero, Knight, Wizard |

Каждый публичный класс и интерфейс находится в отдельном Java-файле. Proxy-классы управляют доступом, счетчиком и отложенным созданием объектов. Bridge использует композицию: пульт хранит Device, герой хранит Weapon. Новые устройства и оружие не требуют изменения пультов и героев.

## Проверка

```sh
python3 verify.py
```
Python 3 нужен только для автоматической проверки, для приложения достаточно JDK. Проверка компилирует все исходники, строго сравнивает stdout каждого из шести примеров и общего Main с файлами `expected/`, затем запускает дополнительные поведенческие проверки. Несовпадение или ошибка компиляции завершает проверку с ошибкой.

`patterns.Main` печатает шесть образцов подряд без дополнительных заголовков и пустых строк. `expected/task1.txt` — `task6.txt` содержат образцы из PDF, `expected/all.txt` — их объединение. Дополнительные проверки не меняют вывод Main.

`verification.txt` содержит отчет выполненной проверки. `actual/all.txt` — фактический вывод общего запуска. Файлы компиляции создаются в `build/` и не включены в архив.
