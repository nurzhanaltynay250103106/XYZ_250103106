package patterns.demo;

import patterns.proxy.*;
import patterns.bridge.*;
import patterns.bridge.rpg.*;

public class Task1Demo {
    public static void main(String[] args) {
        new ProxyImage("salary_sheet.png", "GUEST").show();
        new ProxyImage("salary_sheet.png", "ADMIN").show();
    }
}
