package patterns.bridge.rpg;

public class Wizard extends Hero {
    public Wizard(Weapon weapon) { super(weapon); }
    @Override public void attack() { weapon.use(); }
}
