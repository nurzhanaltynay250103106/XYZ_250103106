package patterns.demo;

import patterns.proxy.*;
import patterns.bridge.*;
import patterns.bridge.rpg.*;

public class Task2Demo {
    public static void main(String[] args) {
        Video video = new ProxyVideo("Cat_Memes.mp4");
        video.play();
        video.play();
        video.play();
    }
}
