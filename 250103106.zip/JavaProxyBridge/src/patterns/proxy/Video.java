package patterns.proxy;

public interface Video { void play(); }
