package patterns.proxy;

public interface Internet { void connectTo(String site); }
