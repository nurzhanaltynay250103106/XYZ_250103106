#!/usr/bin/env python3
"""Compile sources and compare all six demos with the PDF logs."""
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent
classes = root / "build" / "classes"
classes.mkdir(parents=True, exist_ok=True)
sources = sorted(str(p) for p in (root / "src").rglob("*.java"))
subprocess.run(["javac", "--release", "8", "-encoding", "UTF-8", "-d", str(classes)] + sources, check=True)
for i in range(1, 8):
    name = "patterns.demo.Task%dDemo" % i if i < 7 else "patterns.Main"
    expected = root / "expected" / ("task%d.txt" % i if i < 7 else "all.txt")
    result = subprocess.run(["java", "-cp", str(classes), name], capture_output=True, text=True, check=True)
    if result.stdout != expected.read_text(encoding="utf-8"):
        raise AssertionError("Output mismatch: " + name + "\n" + repr(result.stdout))
    print("PASS: " + name + " (exact output match)")
subprocess.run(["java", "-cp", str(classes), "patterns.BehaviorChecks"], check=True)
