package patterns.demo;

import patterns.proxy.*;
import patterns.bridge.*;
import patterns.bridge.rpg.*;

public class Task6Demo {
    public static void main(String[] args) {
        Hero knightWithSword = new Knight(new Sword());
        knightWithSword.attack();
        Hero knightWithWand = new Knight(new MagicWand());
        knightWithWand.attack();
    }
}
