package patterns.demo;

import patterns.proxy.*;
import patterns.bridge.*;
import patterns.bridge.rpg.*;

public class Task3Demo {
    public static void main(String[] args) {
        Internet internet = new SchoolProxyInternet();
        internet.connectTo("wikipedia.org");
        internet.connectTo("gaming.com");
    }
}
