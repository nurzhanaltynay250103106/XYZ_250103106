package patterns.proxy;

public interface Image { void show(); }
