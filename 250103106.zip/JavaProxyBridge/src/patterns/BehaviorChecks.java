package patterns;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import patterns.proxy.*;
import patterns.bridge.*;
import patterns.bridge.rpg.*;

/** Extra checks, separate from the worksheet's console demos. */
public class BehaviorChecks {
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    private static Object field(Object target, String name) throws Exception {
        Field field = target.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(target);
    }
    private static class RecordingDevice implements Device {
        boolean on;
        int level = -1;
        public void turnOn() { on = true; }
        public void turnOff() { on = false; }
        public void setVolume(int level) { this.level = level; }
    }
    public static void main(String[] args) throws Exception {
        PrintStream original = System.out;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        PrintStream captured = new PrintStream(buffer, true, "UTF-8");
        try {
            System.setOut(captured);
            ProxyImage guest = new ProxyImage("salary_sheet.png", "GUEST");
            guest.show();
            require(field(guest, "realImage") == null, "Guest must not load image");
            ProxyImage admin = new ProxyImage("salary_sheet.png", new String("ADMIN"));
            admin.show();
            Object image = field(admin, "realImage");
            require(image != null, "Admin must load image");
            admin.show();
            require(image == field(admin, "realImage"), "Image must be reused");
            ProxyVideo video = new ProxyVideo("Cat_Memes.mp4");
            video.play();
            Object realVideo = field(video, "realVideo");
            video.play(); video.play();
            require(realVideo == field(video, "realVideo"), "Video must be reused");
            require(Integer.valueOf(3).equals(field(video, "viewCount")), "Count must be 3");
            SchoolProxyInternet internet = new SchoolProxyInternet();
            internet.connectTo("gaming.com");
            internet.connectTo("socialmedia.com");
            require(field(internet, "realInternet") == null, "Blocked sites must not create real internet");
            internet.connectTo("wikipedia.org");
            Object realInternet = field(internet, "realInternet");
            internet.connectTo("example.org");
            require(realInternet != null && realInternet == field(internet, "realInternet"), "Internet must be reused");
            RecordingDevice device = new RecordingDevice();
            AdvancedRemote remote = new AdvancedRemote(device);
            remote.powerOn(); remote.mute();
            require(device.on && device.level == 0, "Advanced remote must delegate");
            remote.powerOff();
            require(!device.on, "Power off must delegate");
            new PartyRemote(device).partyMode();
            require(device.on && device.level == 100, "Party mode must delegate");
            buffer.reset();
            new Knight(new Sword()).attack();
            new Knight(new MagicWand()).attack();
            new Wizard(new Sword()).attack();
            new Wizard(new MagicWand()).attack();
            String pair = "Slash! Dealing 20 physical damage.\nZap! Dealing 35 magic damage.\n";
            require(buffer.toString("UTF-8").replace("\r\n", "\n").equals(pair + pair), "All four hero/weapon combinations must work");
            buffer.reset();
            SmartLight light = new SmartLight();
            light.turnOff(); light.setVolume(75);
            require(buffer.toString("UTF-8").replace("\r\n", "\n").equals("Smart Light shuts off.\nSmart Light brightness set to: 75%\n"), "Light methods must match worksheet");
        } finally {
            System.setOut(original);
            captured.close();
        }
        System.out.println("PASS: additional behavior checks");
    }
}
