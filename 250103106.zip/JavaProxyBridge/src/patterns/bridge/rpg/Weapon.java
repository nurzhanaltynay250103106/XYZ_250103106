package patterns.bridge.rpg;

public interface Weapon { void use(); }
