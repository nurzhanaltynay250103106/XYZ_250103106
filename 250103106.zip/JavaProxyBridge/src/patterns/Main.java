package patterns;

import patterns.demo.*;

public class Main {
    public static void main(String[] args) {
        Task1Demo.main(args);
        Task2Demo.main(args);
        Task3Demo.main(args);
        Task4Demo.main(args);
        Task5Demo.main(args);
        Task6Demo.main(args);
    }
}
